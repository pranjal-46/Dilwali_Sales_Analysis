# Diwali_Sales_Analysis
Python project for beginners- Analyze Diwali sales data to improve customer experience and sales
complete project on GitHub: https://0gaurav4.github.io/final-year23/Diwali%20Sales%20Prediction/web/index.html