# final-year23
Diwali Sales Analysis : https://0gaurav4.github.io/final-year23/Diwali%20Sales%20Prediction/web/index.html 

Laptop Price Prediction : https://0gaurav4.github.io/final-year23/Laptop%20Price%20Prediction/templates/index.html
